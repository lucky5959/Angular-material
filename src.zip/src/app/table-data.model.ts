export interface TableData {
    from: Date;
    to: Date;
    id:string;
    name:string;
    email:string;
  }
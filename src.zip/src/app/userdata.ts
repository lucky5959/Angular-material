export interface userdata{
    id:number;
    name:string;
    email:string;
}